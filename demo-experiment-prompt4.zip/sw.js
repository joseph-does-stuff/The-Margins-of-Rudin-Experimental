/* Offline support for The Margins of Rudin demo. The page is fetched fresh when online (so updates
   arrive) and served from the cache when offline; fonts and icons come from the cache. */
const CACHE="margins-demo-6fbc9b587d";
const SHELL=["./", "index.html", "content/ch1.json", "js/content.js", "js/player-model.js", "js/proof-framework.js", "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png", "icons/apple-touch-icon.png", "fonts/stix-two-text-greek-400-normal.woff2", "fonts/stix-two-text-latin-ext-400-normal.woff2", "fonts/stix-two-text-latin-400-normal.woff2", "fonts/stix-two-text-greek-400-italic.woff2", "fonts/stix-two-text-latin-ext-400-italic.woff2", "fonts/stix-two-text-latin-400-italic.woff2", "fonts/stix-two-text-greek-600-normal.woff2", "fonts/stix-two-text-latin-ext-600-normal.woff2", "fonts/stix-two-text-latin-600-normal.woff2", "fonts/caveat-latin-ext-500-normal.woff2", "fonts/caveat-latin-500-normal.woff2", "fonts/caveat-latin-ext-600-normal.woff2", "fonts/caveat-latin-600-normal.woff2", "fonts/karla-latin-ext-500-normal.woff2", "fonts/karla-latin-500-normal.woff2", "fonts/karla-latin-ext-700-normal.woff2", "fonts/karla-latin-700-normal.woff2", "fonts/nothing-you-could-do-latin-400-normal.woff2"];
self.addEventListener("install",e=>{ e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())); });
self.addEventListener("activate",e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith("margins-demo-")&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener("fetch",e=>{
  const r=e.request; if(r.method!=="GET") return;
  const url=new URL(r.url); if(url.origin!==location.origin) return;
  if(r.mode==="navigate" || url.pathname.endsWith("/index.html")){
    e.respondWith(fetch(r).then(res=>{ const copy=res.clone(); caches.open(CACHE).then(c=>c.put("index.html",copy)); return res; }).catch(()=>caches.match("index.html")));
    return;
  }
  /* Chapter content and the game scripts: network first so edits show up, cache when offline. */
  if(url.pathname.includes("/content/") || url.pathname.includes("/js/")){
    e.respondWith(fetch(r).then(res=>{ if(res.ok){ const copy=res.clone(); caches.open(CACHE).then(c=>c.put(r,copy)); } return res; }).catch(()=>caches.match(r, {ignoreSearch:true})));
    return;
  }
  e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{ if(res.ok){ const copy=res.clone(); caches.open(CACHE).then(c=>c.put(r,copy)); } return res; })));
});
