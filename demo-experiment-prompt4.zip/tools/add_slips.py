"""Prompt 3: add the three Chapter 1 SLIP levels and plain-language names for the flaw types."""
import json
p = 'content/ch1.json'
d = json.load(open(p, encoding='utf-8'))

FLAWS = {  # short name + one plain sentence; these become the player's "flaw types" toolkit
 'M-Q-ORDER':      ('Quantifiers in the wrong order', 'Something chosen once is used for every case, when it should have been chosen after each case is given.'),
 'M-CONVERSE':     ('Converse mix-up', '“If A then B” is used as if it said “if B then A”.'),
 'M-ASSUME-PROVE': ('Assuming what you’re proving', 'A step quietly relies on the very statement being proved.'),
 'M-EX-MASQ':      ('An example posing as a proof', 'A few cases are checked and the claim is declared true for all of them.'),
 'M-REP-UNIQ':     ('Hidden uniqueness assumption', 'An object is treated as if it could only be written or chosen one way.'),
 'M-WLOG':         ('Unjustified “without loss of generality”', 'A special case is assumed, or something is assumed to exist, without a reason it’s allowed.'),
 'M-SUP-MAX':      ('Sup mistaken for max', 'The least upper bound is treated as the largest element, which a set may not have.'),
}
d['misconceptions']['M-Q-ORDER']['label'] = 'reversed quantifier order (δ or N chosen before ε)'
for k, (short, plain) in FLAWS.items():
    d['misconceptions'][k]['short'] = short
    d['misconceptions'][k]['plain'] = plain

CLEAN = "R.V. double-checked that line — it's clean."

slip_irrational = {
 "id": "c1-slip-irrational", "rudin": "1.1", "kind": "SLIP", "title": "Find R.V.'s slip: √2 is not rational",
 "type": "Slip", "who": "rv",
 "statement": "No rational number p has p² = 2.",
 "intro": "R.V. copied out this proof from memory, and one line doesn't follow. Tap the line that's wrong.",
 "proof_lines": [
  {"n": 1, "text": "Suppose, for a contradiction, that p = m/n with p² = 2, where m and n are integers and n ≠ 0."},
  {"n": 2, "text": "Dividing out common factors, we may assume m and n are not both even.",
   "clean_note": "Cancelling common factors of 2 from m and n, as many times as needed, doesn't change p, so this assumption is free."},
  {"n": 3, "text": "Squaring gives m² = 2n², so m² is even."},
  {"n": 4, "text": "The square of an even number is even, so m is even."},
  {"n": 5, "text": "Write m = 2k. Then 4k² = 2n², that is, n² = 2k², so n² is even."},
  {"n": 6, "text": "Repeating line 4's step with n in place of m, n is even.",
   "clean_note": "Line 6 only repeats line 4's step. Once that step is fixed, this line is fine. Look for where it first goes wrong."},
  {"n": 7, "text": "So m and n are both even, which contradicts line 2. Hence no rational p has p² = 2."}
 ],
 "flaw_line": 4, "flaw_type": "M-CONVERSE",
 "flaw_note": "Line 4 knows “m even ⇒ m² even” but needs “m² even ⇒ m even”. That's the converse, and it needs its own proof.",
 "type_options": [
  {"id": "M-CONVERSE"},
  {"id": "M-ASSUME-PROVE", "feedback": "Line 4 doesn't use that √2 is irrational. It uses a true fact about even numbers, pointed the wrong way."},
  {"id": "M-REP-UNIQ", "feedback": "Line 4 doesn't treat m or n as if they could be written only one way. Its trouble is the direction of an implication."},
  {"id": "M-EX-MASQ", "feedback": "No examples are checked in line 4. It cites a general fact, just the wrong direction of it."}
 ],
 "fix_options": [
  {"text": "If m were odd, m = 2j + 1, then m² = 4j² + 4j + 1 would be odd. So m² even forces m even.", "correct": True},
  {"text": "Since 2 divides 2n² = m², in fact 4 divides m², so m is even.",
   "feedback": "Getting 4 | m² from 2 | m² already uses that m is even, and going from 4 | m² to ‘m is even’ is the same converse again."},
  {"text": "Check: 2² = 4, 4² = 16, 6² = 36. The even squares come from even numbers, so m is even.",
   "feedback": "Three cases aren't a proof for every m. That's an example posing as a proof. And squaring even numbers only checks ‘even ⇒ even square’, the direction you already had."}
 ],
 "note": None
}

slip_archimedean = {
 "id": "c1-slip-archimedean", "rudin": "1.20", "kind": "SLIP", "title": "Find R.V.'s slip: the numbers 1/n",
 "type": "Slip", "who": "rv",
 "statement": "The set E = {1/n : n a positive integer} has inf E = 0.",
 "intro": "R.V. leaned on the Archimedean property (1.20(a)) here, and one line goes wrong. Tap the line that's wrong.",
 "proof_lines": [
  {"n": 1, "text": "Every element 1/n of E is positive, so 0 is a lower bound of E."},
  {"n": 2, "text": "By 1.20(a) with y = 1, there is a positive integer N such that Nε > 1 for every ε > 0."},
  {"n": 3, "text": "Now let ε > 0 be given.",
   "clean_note": "Starting with an arbitrary ε > 0 is exactly right for showing no positive number is a lower bound."},
  {"n": 4, "text": "Then Nε > 1, so 1/N < ε.",
   "clean_note": "Given line 2, this step is right: Nε > 1 means 1/N < ε. The trouble is where N came from. Look earlier."},
  {"n": 5, "text": "Since 1/N is in E, ε is not a lower bound of E."},
  {"n": 6, "text": "So no positive number is a lower bound of E, and the greatest lower bound is 0: inf E = 0."}
 ],
 "flaw_line": 2, "flaw_type": "M-Q-ORDER",
 "flaw_note": "1.20(a) gives an N for each ε, chosen after ε. No single N works for every ε: take ε = 1/(2N).",
 "type_options": [
  {"id": "M-Q-ORDER"},
  {"id": "M-EX-MASQ", "feedback": "No cases are checked in line 2. It states one N for every ε at once, but 1.20(a) only gives an N after ε is chosen."},
  {"id": "M-ASSUME-PROVE", "feedback": "Line 2 doesn't use inf E = 0. It misreads the order of “for every ε” and “there is N”."},
  {"id": "M-SUP-MAX", "feedback": "No supremum or maximum appears in line 2. The problem is which choice comes first."}
 ],
 "fix_options": [
  {"text": "Move it after line 3: given ε > 0, 1.20(a) with x = ε and y = 1 gives a positive integer N, depending on ε, with Nε > 1.", "correct": True},
  {"text": "Take N = 1: then Nε > 1 for every ε > 0, so one N works for all ε.",
   "feedback": "For ε = 1/2, 1·ε = 1/2 isn't greater than 1. No fixed N can work for every ε."},
  {"text": "Choose N larger than 1/ε for every ε > 0 at once, so Nε > 1 always holds.",
   "feedback": "1/ε gets as large as you like as ε shrinks, so no single N beats all of them. Same slip."}
 ],
 "note": None
}

slip_june_sup = {
 "id": "c1-slip-june-sup", "rudin": "1.8", "kind": "SLIP", "title": "June explains sup to Teo — with one slip for you to catch",
 "type": "Slip", "who": "june", "bonus": True,
 "statement": "Teo drops by and asks what a ‘sup’ is. June answers before Nell can.",
 "intro": "Nell hears one slip. Tap the line where June goes wrong.",
 "proof_lines": [
  {"n": 1, "text": "“Take a set of real numbers, not empty, that has a ceiling: some number at or above everything in it.”"},
  {"n": 2, "text": "“Any such number is an upper bound. There are lots of them: if 10 works, so does 11.”"},
  {"n": 3, "text": "“The sup is the smallest upper bound. It's an upper bound, and nothing smaller is.”"},
  {"n": 4, "text": "“So the sup is always the biggest number in the set, the one sitting right at the top.”"},
  {"n": 5, "text": "“For {1, 2, 3}, the sup is 3.”",
   "clean_note": "That one's true: 3 bounds {1, 2, 3} and nothing smaller does. Here the sup happens to be in the set."},
  {"n": 6, "text": "“And ℝ guarantees it: every nonempty set of reals with an upper bound has a sup in ℝ.”"}
 ],
 "flaw_line": 4, "flaw_type": "M-SUP-MAX",
 "flaw_note": "The numbers below 1 have no biggest number, but their sup is 1. The sup needn't be in the set at all.",
 "type_options": [
  {"id": "M-SUP-MAX"},
  {"id": "M-EX-MASQ", "feedback": "Line 5's example is fine. Line 4 is a general claim, and it's false on its own."},
  {"id": "M-REP-UNIQ", "feedback": "Line 4 doesn't assume anything can be written only one way. It swaps one idea (least upper bound) for another (largest element)."},
  {"id": "M-ASSUME-PROVE", "feedback": "June isn't proving anything in line 4; she's describing the sup, and the description is wrong."}
 ],
 "fix_options": [
  {"text": "“The sup can be in the set or not: the numbers below 1 have no biggest number, and their sup is 1.”", "correct": True},
  {"text": "“The sup is never in the set; it always sits just past the top.”",
   "feedback": "The sup of {1, 2, 3} is 3, which is in the set."},
  {"text": "“The sup is the smallest upper bound that's in the set.”",
   "feedback": "The numbers below 1 have no upper bound inside the set, yet their sup is 1."}
 ],
 "note": None
}

for s in (slip_irrational, slip_archimedean, slip_june_sup):
    assert 5 <= len(s['proof_lines']) <= 8 and len(s['type_options']) == 4 and len(s['fix_options']) == 3
    assert sum(1 for f in s['fix_options'] if f.get('correct')) == 1
    assert s['type_options'][0]['id'] == s['flaw_type'] and all(t['id'] in d['misconceptions'] for t in s['type_options'])
    for l in s['proof_lines']:
        l.setdefault('clean_note', None)
    s['clean_default'] = "Nell nods at that line. It's clean." if s.get('who') == 'june' else CLEAN

pages = [pg for pg in d['pages'] if not pg['id'].startswith('c1-slip-')]
def insert_after(pid, page):
    i = next(i for i, pg in enumerate(pages) if pg['id'] == pid)
    pages.insert(i + 1, page)
insert_after('c1-1-1', slip_irrational)
insert_after('c1-1-20', slip_archimedean)
# The chat-style playback is retired in favor of the SLIP version (kept in the file, hidden).
for pg in pages:
    if pg['id'] == 'c1-j-playback': pg['hidden'] = True
pages.append(slip_june_sup)
d['pages'] = pages
json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print([pg['id'] for pg in pages if 'slip' in pg['id']], len(pages), 'pages')
