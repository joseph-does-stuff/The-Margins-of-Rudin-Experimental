// Tests for the BOSS framework checks against the 1.21 content. Run: node tools/proof_framework_test.js
const assert = require('assert');
const F = require('../js/proof-framework.js');
const doc = require('../content/ch1.json');
const fw = doc.pages.find(p => p.id === 'c1-1-21').framework;
const [X, N] = fw.first_blanks, [Y, ONLY] = fw.last_blanks;
let n = 0;
const ok = (b, inputs) => inputs.forEach(s => { assert.strictEqual(F.checkBlank(b, s).ok, true, 'should accept: ' + s); n++; });
const no = (b, inputs) => inputs.forEach(s => { assert.strictEqual(F.checkBlank(b, s).ok, false, 'should reject: ' + s); n++; });
const hint = (b, s, frag) => { const r = F.checkBlank(b, s); assert.strictEqual(r.ok, false, s); assert.ok(r.hint.includes(frag), s + ' -> ' + r.hint); n++; };

ok(X, ['real', 'real number', 'a real number', 'Positive real', 'positive real number', 'element of ℝ', 'x ∈ ℝ', '∈ ℝ', 'ℝ', 'Real number.']);
no(X, ['integer', 'rational number', 'irrational real number', 'negative real', 'not a real number', 'complex number', 'number', '']);
hint(X, 'irrational number', 'needn’t be irrational'); hint(X, 'integer', 'any positive real'); hint(X, 'positive number', 'Which number system'); hint(X, 'blah', 'What kind of object is x');

ok(N, ['positive integer', 'a positive integer', 'Positive int', 'natural number', 'natural', 'counting number', 'integer ≥ 2', 'integer >= 2', 'integer greater than 1',
       'integer ≥ 1', 'integer greater than or equal to 1', 'integer greater than zero', 'integer > 0', 'integer at least 2', 'positive integer ≥ 2', 'element of ℕ', 'n ∈ ℕ', 'ℕ', 'ℤ+', 'positive whole number']);
no(N, ['integer', 'whole number', 'nonnegative whole number', 'natural number including 0', 'non-positive integer', 'integer >=10', 'integer at least 100',
       'real number', 'negative integer', 'integer ≥ 0', 'positive real']);
hint(N, 'integer', 'which integers'); hint(N, 'real', 'exponent'); hint(N, 'nonnegative integer', 'at least 1'); hint(N, 'positive real', 'exponent');

ok(Y, ['sup E', 'supE', 'sup(E)', 'the sup of E', 'supremum of E', 'least upper bound of E', 'the least upper bound of E', 'lub E']);
no(Y, ['E', 'x', 'y', 'x^(1/n)', 'max E', 'inf E', 'sup', 'y^n - x']);
hint(Y, 'E', 'Not E itself'); hint(Y, 'x^(1/n)', 'can’t assume'); hint(Y, 'max E', 'no largest'); hint(Y, 'sup', 'which set'); hint(Y, 'inf E', 'Wrong side');

ok(ONLY, ['only', 'unique', 'one', 'the one', 'exactly one', 'one and only', 'only one', 'sole', 'the unique one']);
no(ONLY, ['not unique', 'a', 'some', 'least', 'largest', 'non-unique']);
hint(ONLY, 'not unique', 'Uniqueness'); hint(ONLY, 'least', 'how many'); hint(ONLY, 'some', 'more than existence');

const S = fw.middle_steps, ids = S.map(s => s.id);
assert.strictEqual(F.scoreOrder(S, ids).credit, 6); n++;
assert.strictEqual(F.scoreOrder(S, ['s5', 's2', 's3', 's4', 's1', 's7', 's6']).valid, true); n++;          // another valid order
assert.strictEqual(F.scoreOrder(S, ['s2', 's3', 's4', 's5', 's6', 's1', 's7']).valid, true); n++;
assert.strictEqual(F.scoreOrder(S, ['s1', 's2', 's3', 's4', 's5', 's7', 's6']).valid, true); n++;          // the two cases swapped
assert.strictEqual(F.scoreOrder(S, ['s2', 's3', 's4', 's5', 's6', 's7', 's1']).valid, false); n++;         // s7 needs s1
const bad = F.scoreOrder(S, ['s4', 's1', 's2', 's3', 's5', 's6', 's7']);
assert.strictEqual(bad.valid, false); assert.strictEqual(bad.credit, 4); assert.deepStrictEqual(bad.good, [false, true, true, false, true, true]); n += 3;
assert.strictEqual(F.scoreOrder(S, ['s7', 's6', 's5', 's4', 's3', 's2', 's1']).credit, 0); n++;
console.log(n, 'checks passed');
