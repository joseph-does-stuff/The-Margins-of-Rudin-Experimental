"""Prompt 4 side fix: three pages printed a word twice (the circled word plus the same word in the text)."""
import json
p = 'content/ch1.json'
d = json.load(open(p, encoding='utf-8'))
pg = {x['id']: x for x in d['pages']}
n = 0
def fix(s, a, b):
    global n
    if a in s: n += 1; return s.replace(a, b)
    return s
pg['c1-1-15']['body_html'] = fix(pg['c1-1-15']['body_html'], "data-circle='m1'>exists</span> exists because", "data-circle='m1'>exists</span> because")
for pid, cid, a, b in [('c1-1-20', 'a4', 'because [[a5]] m + 1', '[[a5]] m + 1'), ('c1-1-21', 'r4', 'and [[r4b]] each is', 'and [[r4b]] is')]:
    for c in pg[pid]['circles']:
        if c['id'] == cid:
            for o in c['options']:
                if o.get('margin_note'): o['margin_note'] = fix(o['margin_note'], a, b)
json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('fixed', n)
