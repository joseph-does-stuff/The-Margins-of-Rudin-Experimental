"""Prompt 4: the proof framework for the 1.21 boss (n-th roots exist and are unique)."""
import json
p = 'content/ch1.json'
d = json.load(open(p, encoding='utf-8'))
boss = next(pg for pg in d['pages'] if pg['id'] == 'c1-1-21')

L = {  # licenses used across the steps
 'field':  'Ordered-field rules: multiplying by a positive number keeps < (1.18)',
 'ub':     'Definition of an upper bound (1.7)',
 'lub':    'Least-upper-bound property of ℝ (1.19)',
 'factor': 'Factoring: bⁿ − aⁿ = (b − a)(bⁿ⁻¹ + bⁿ⁻²a + ⋯ + aⁿ⁻¹)',
 'sup_i':  'sup E is an upper bound of E (1.8(i))',
 'sup_ii': 'Nothing smaller than sup E is an upper bound of E (1.8(ii))',
 'arch':   'Archimedean property (1.20(a))',
 'dense':  'ℚ is dense in ℝ (1.20(b))',
 'binom':  'Binomial theorem',
 'roots':  'n-th roots exist (1.21)',
}
def lic(right, *wrong):
    return [{'text': L[right], 'correct': True}] + [{'text': L[k], 'correct': False, 'feedback': fb} for k, fb in wrong]

bh = boss['body_html']
bh = bh.replace("Then <span class='gap' data-circle='r5'>then</span> (y + h)", "<span class='gap' data-circle='r5'>Then</span> (y + h)")
bh = bh.replace("That is <span class='gap' data-circle='r6'>impossible</span> impossible.", "That is <span class='gap' data-circle='r6'>impossible</span>.")
boss['body_html'] = bh
for c in boss['circles']:
    if c['id'] == 'r5': c['word'] = 'Then'
boss['framework'] = {
 'intro': 'R.V. starred this one. Build the proof yourself: say what you are given, say what done looks like, then put the middle in order and name what licenses each step.',
 'first_line_blank': 'Let x > 0 be a ___, and let n be a ___. (For n = 1 take y = x, so assume n ≥ 2.)',
 'first_line_answer': ['real number', 'positive integer'],
 # Answers are normalized first (lowercase; ≥, "at least", "greater than or equal to" -> ">="; "greater/more than" -> ">";
 # no spaces around < > = ∈ ^; braces and leading a/an/the dropped), then must match one `accept` pattern exactly.
 'first_blanks': [
  {'answer': 'real number',
   'accept': [r'^(positive |nonnegative |non-negative )?(real|real number|real no\.)$', r'^(element|member) of ℝ$', r'^(x)?∈ℝ$', r'^ℝ$', r'^number in ℝ$'],
   'hints': [{'match': r'irrational', 'text': 'x needn’t be irrational: any positive real works, like 2 or √2.'},
             {'match': r'integer|natural|whole|rational|counting|ℕ|ℤ|ℚ', 'text': 'Check the theorem statement: x can be any positive real, like 2 or √2.'},
             {'match': r'complex|ℂ', 'text': 'x > 0 only makes sense for reals. What kind of object is x here? Check the theorem statement.'},
             {'match': r'negative|not ', 'text': 'The statement gives x > 0. What kind of number is it?'},
             {'match': r'number', 'text': 'Which number system? Chapter 1 has been building it.'}],
   'hint': 'What kind of object is x here? Check the theorem statement.'},
  {'answer': 'positive integer',
   'accept': [r'^positive (integer|int|whole number)(>=?[012])?$', r'^natural( number)?$', r'^counting number$',
              r'^(integer|int|natural number)(>=[12]|>[01])$', r'^(element|member) of ℕ$', r'^(n)?∈ℕ$', r'^ℕ$', r'^(ℤ\+|ℤ⁺|z\+)$'],
   'hints': [{'match': r'non|negative|>=0|including|zero', 'text': 'n has to be at least 1, and the proof takes n ≥ 2. Which integers does that leave?'},
             {'match': r'real|rational|number$', 'text': 'n is an exponent that counts factors in yⁿ. What kind of number is it?'},
             {'match': r'^(integer|int)$|integer', 'text': 'Almost: which integers is n allowed to be? Check the statement.'}],
   'hint': 'What kind of object is n here? Check the theorem statement.'}
 ],
 'last_line_blank': 'Therefore y = ___ satisfies yⁿ = x, and by the uniqueness step y is the ___ positive real that does.',
 'last_line_answer': ['sup E', 'only'],
 'last_blanks': [
  {'answer': 'sup E',
   'accept': [r'^sup ?e$', r'^sup\(e\)$', r'^(the )?(sup|supremum|least upper bound|lub) of e$', r'^lub ?e$', r'^sup ?\{t>0:t\^n<x\}$'],
   'hints': [{'match': r'^e$', 'text': 'Not E itself: one number built from E.'},
             {'match': r'root|1/n|\^\(1/n\)|√', 'text': 'That’s what y turns out to be, but the proof can’t assume it exists. Name how the proof builds y.'},
             {'match': r'max|largest|biggest', 'text': 'E has no largest element. What do you take of a bounded set instead?'},
             {'match': r'inf|lower', 'text': 'Wrong side: the set E is bounded above, so take its least upper bound.'},
             {'match': r'sup|upper', 'text': 'Close. The sup of which set?'}],
   'hint': 'Existence proofs in this chapter build y from a set. Which set, and what do you take of it?'},
  {'answer': 'only',
   'accept': [r'^(only|unique|one|the one|only one|exactly one|one and only|one and only one|sole|single|only one|unique one|the only one|the unique one)$'],
   'hints': [{'match': r'not|non', 'text': 'Uniqueness is exactly what the first step proved.'},
             {'match': r'least|largest|greatest|smallest|sup|biggest', 'text': 'y is sup E, but this blank is about how many such y there are.'},
             {'match': r'^(a|some|an|first|positive)$', 'text': 'The theorem promises more than existence. Re-read “exactly one” in the statement.'}],
   'hint': 'What does the uniqueness step let you say about y?'}
 ],
 'middle_steps': [
  {'id': 's1', 'short': 'powers keep order (uniqueness)', 'after': [],
   'text': 'If 0 < y₁ < y₂, then y₁ⁿ < y₂ⁿ. So at most one positive y has yⁿ = x.',
   'licensed_by': L['field'],
   'license_options': lic('field', ('lub', 'No sup is needed here. It is just multiplying inequalities by positive numbers, n times.'),
                                  ('roots', 'That is the theorem being proved, so using it here would be circular.'))},
  {'id': 's2', 'short': 'E is not empty', 'after': [],
   'text': 'Let E be the set of t > 0 with tⁿ < x. The number t = x/(1 + x) lies in E, so E is not empty.',
   'licensed_by': L['field'],
   'license_options': lic('field', ('arch', 'Nothing has to beat a bound here: t is written down explicitly, and 0 < t < 1 gives tⁿ ≤ t < x.'),
                                  ('sup_i', 'E has no sup yet. This step only shows that E has an element.'))},
  {'id': 's3', 'short': 'E has an upper bound', 'after': ['s2'],
   'text': '1 + x is an upper bound of E: if t > 1 + x, then tⁿ ≥ t > x, so t is not in E.',
   'licensed_by': L['ub'],
   'license_options': lic('ub', ('lub', 'That property needs an upper bound to start from. This step is finding one.'),
                               ('arch', '1 + x is given explicitly, so no Archimedean step is needed.'))},
  {'id': 's4', 'short': 'y = sup E exists', 'after': ['s2', 's3'],
   'text': 'So y = sup E exists, and y > 0.',
   'licensed_by': L['lub'],
   'license_options': lic('lub', ('arch', 'The Archimedean property gives integers past a bound, not a least upper bound.'),
                                ('dense', 'Density finds rationals between reals. It doesn’t produce a sup.'))},
  {'id': 's5', 'short': 'the estimate bⁿ − aⁿ < (b − a)nbⁿ⁻¹', 'after': [],
   'text': 'For 0 < a < b and n ≥ 2: bⁿ − aⁿ < (b − a)·n·bⁿ⁻¹.',
   'licensed_by': L['factor'],
   'license_options': lic('factor', ('binom', 'Expanding bⁿ = (a + (b − a))ⁿ gives a lower bound on bⁿ − aⁿ, with aⁿ⁻¹. The upper bound with bⁿ⁻¹ comes from factoring.'),
                                   ('lub', 'This is an inequality between two given numbers. No sup is involved.'))},
  {'id': 's6', 'short': 'the case yⁿ < x', 'after': ['s4', 's5'],
   'text': 'If yⁿ < x, choose 0 < h < 1 with h < (x − yⁿ)/(n(y + 1)ⁿ⁻¹). The estimate gives (y + h)ⁿ < x, so y + h is in E, which is impossible.',
   'licensed_by': L['sup_i'],
   'license_options': lic('sup_i', ('sup_ii', 'That is the other half of the definition. Here the trouble is an element of E above y.'),
                                  ('arch', 'h is simply a positive number below a positive bound. The contradiction comes from y being an upper bound.'))},
  {'id': 's7', 'short': 'the case yⁿ > x', 'after': ['s1', 's4', 's5'],
   'text': 'If yⁿ > x, put k = (yⁿ − x)/(n·yⁿ⁻¹), so 0 < k < y. For t ≥ y − k, tⁿ ≥ (y − k)ⁿ (as in the uniqueness step), and the estimate gives (y − k)ⁿ > x. So tⁿ > x, and y − k is an upper bound of E smaller than y, which is impossible.',
   'licensed_by': L['sup_ii'],
   'license_options': lic('sup_ii', ('sup_i', 'y being an upper bound isn’t contradicted. What can’t exist is a smaller upper bound.'),
                                   ('lub', 'That property gave y its existence. The contradiction here is with y being the least.'))},
 ],
}
fw = boss['framework']
ids = [s['id'] for s in fw['middle_steps']]
assert all(s.get('short') for s in fw['middle_steps'])
assert 5 <= len(ids) <= 7
import re
for b in fw['first_blanks'] + fw['last_blanks']:
    for r in b['accept'] + [h['match'] for h in b['hints']]: re.compile(r)
for s in fw['middle_steps']:
    assert len(s['license_options']) == 3 and s['license_options'][0]['text'] == s['licensed_by']
    assert all(a in ids[:ids.index(s['id'])] for a in s['after'])
json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('framework added:', len(ids), 'steps')
