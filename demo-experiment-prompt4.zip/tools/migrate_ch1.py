"""One-off migration: pull the LEVELS data out of index.html and write content/ch1.json
in the chapter-file schema. Run from the repo root: python3 tools/migrate_ch1.py"""
import json, re, sys
src = sys.argv[1] if len(sys.argv) > 1 else 'index.html'
s = open(src, encoding='utf-8').read()
i = s.find('const LEVELS = ') + len('const LEVELS = ')
LEVELS, _ = json.JSONDecoder().raw_decode(s, i)
TITLE = 'The Real and Complex Number Systems'

def body_html(l):
    out = []
    for para in l['proof']:
        para = re.sub(r'\[\[(\w+)\]\]', lambda m: f"<span class='gap' data-circle='{m.group(1)}'>{l['gaps'][m.group(1)]['w']}</span>", para)
        out.append(f'<p>{para}</p>')
    return ''.join(out)

def options(g):
    opts = []
    for text, ok, fb in g['opts']:
        o = {'text': text, 'correct': bool(ok)}
        if ok:
            o['margin_note'] = g['ink']
            if 'back' in g: o['june_reply'] = g['back']
        else:
            o['feedback'] = fb
        opts.append(o)
    return opts

def circle(gid, g):
    c = {'id': gid, 'word': g['w'], 'label': g['rv'], 'question': g['q'], 'options': options(g)}
    if g.get('monster'): c['monster'] = {'name': g['monster'][0], 'text': g['monster'][1]}
    return c

pages = []
for l in LEVELS:
    kind = l['role'].upper()
    p = {'id': l['id'], 'rudin': l['no'], 'kind': kind, 'title': l['name'], 'type': l['type'],
         'statement': l['stmt'], 'body_html': body_html(l)}
    if kind in ('JUNE', 'PLAYBACK'):
        dlg = []
        for gid, g in l['gaps'].items():
            dlg.append({'speaker': 'june', 'text': g['q']})
            c = circle(gid, g); c.pop('question')
            dlg.append({'speaker': 'choice', 'circle': gid, **{k: v for k, v in c.items() if k != 'id'}})
        p['dialogue'] = dlg
        for k_old, k_new in (('before', 'before'), ('terms', 'terms'), ('open', 'open_lines'), ('close', 'close_lines')):
            if k_old in l: p[k_new] = l[k_old]
        p['your_words_prompt'] = None
    else:
        p['circles'] = [circle(gid, g) for gid, g in l['gaps'].items()]
    p['note'] = l['note']
    pages.append(p)

doc = {'chapter': 1, 'title': TITLE, 'pages': pages, 'misconceptions': {}}
json.dump(doc, open('content/ch1.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(LEVELS, open('tools/levels_original.json', 'w', encoding='utf-8'), ensure_ascii=False)
print(len(pages), 'pages ->', 'content/ch1.json')
