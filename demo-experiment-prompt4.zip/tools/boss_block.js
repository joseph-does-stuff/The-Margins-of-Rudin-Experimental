/* ---------- BOSS pages: build the proof from its frame ----------
   Stage 1: fill in the first line. Stage 2: fill in the last line. Stage 3: put the middle steps in order
   (tap-to-order). Stage 4: name the license for each step. Then the full proof renders with R.V.'s notes. */
const BOSS_KEY="margins-of-rudin-demo-boss";
const BX_STAGES=["first","last","order","license","done"];
let BOSSES={}; try{ BOSSES=JSON.parse(localStorage.getItem(BOSS_KEY)||"{}")||{}; }catch(e){ BOSSES={}; }
function saveBoss(){ try{ localStorage.setItem(BOSS_KEY, JSON.stringify(BOSSES)); }catch(e){} }
function bxLine(){ return {vals:["",""],ok:[false,false],miss:[0,0],hint:["",""],shown:[false,false]}; }
function bxFresh(){ return {stage:"first", first:bxLine(), last:bxLine(), pool:null, order:[], checks:0, firstCredit:null, check:null, lic:{}, licOrder:{}}; }
function bossRec(id){ const r=BOSSES[id]||(BOSSES[id]={done:false,best:null,last:null}); if(!r.run) r.run=bxFresh(); return r; }
function bossBuilding(l){ return l.role==="Boss" && !!l.framework && (!isDone(l) || !!(BOSSES[l.id] && BOSSES[l.id].rebuilding)); }
function bxEsc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
function bxStepOf(L,id){ return L.framework.middle_steps.find(s=>s.id===id); }
/* The first dependency problem in an order: a step placed above something it needs. */
function bxProblem(L,order){
  const pos=Object.fromEntries(order.map((id,i)=>[id,i]));
  for(const id of order){ const s=bxStepOf(L,id); const need=(s.after||[]).find(a=>pos[a]>pos[id]); if(need) return {id, need}; }
  return null;
}
function bxScore(run, F){
  const lines=["first","last"].reduce((t,k)=>t+run[k].ok.filter((ok,i)=>ok && !run[k].miss[i] && !run[k].shown[i]).length,0);
  const lic=F.middle_steps.filter(s=>{ const r=run.lic[s.id]; return r && r.ok && r.tries.length===1; }).length;
  const n=F.middle_steps.length;
  return {lines, linesOf:F.first_blanks.length+F.last_blanks.length, order:run.firstCredit||0, orderOf:n-1, lic, licOf:n};
}
const bxSum = s => s ? s.lines+s.order+s.lic : -1;

function runBoss(animate){
  const L=LV, F=L.framework, rec=bossRec(L.id), run=rec.run, st=run.stage, si=BX_STAGES.indexOf(st);
  if(!run.pool){ const ids=F.middle_steps.map(s=>s.id); let a; let k=0; do{ a=slipShuffle(ids.length).map(i=>ids[i]); k++; }while(MORProof.isValidOrder(F.middle_steps,a) && k<50); run.pool=a; saveBoss(); }
  let h=`<div class="lvname">${L.name} · <b>★ R.V.'s star</b></div><p class="thm"><span class="num">${L.no} ${L.type}</span> <span class="it">${L.stmt}</span></p>`;
  h+=`<p class="slip-intro">${F.intro}</p>`;
  h+=`<ol class="bx-track" aria-label="Stages">${["First line","Last line","Order the middle","Name the licenses"].map((t,i)=>`<li class="${i<si?"did":i===si?"on":""}"><span class="k">${i<si?"✓":i+1}</span>${t}</li>`).join("")}</ol>`;
  h+=`<div class="bx-proof"><div class="bx-lab"><span class="proof-lab">Proof</span></div>`;
  h+=bxLineHTML(L,"first", st==="first");
  if(st==="first"||st==="last") h+=`<div class="bx-ghost">⋮&ensp;the middle comes once both ends are in place</div>`;
  else if(st==="order") h+=bxOrderHTML(L);
  else h+=bxLicHTML(L);
  h+= st==="first" ? `<div class="bx-line wait"><span class="bx-tag">Last line</span>Fill in the first line first.</div>` : bxLineHTML(L,"last", st==="last");
  h+=`</div>`;
  text.innerHTML=h;
  margin.innerHTML=""; margin.style.minHeight="0px";
  bxWire(L);
  checkDone();
  if(animate) window.scrollTo({top:0,behavior:"auto"});
}
function bxLineHTML(L, which, live){
  const F=L.framework, run=bossRec(L.id).run, part=run[which], blanks=F[which+"_blanks"];
  const bits=F[which+"_line_blank"].split("___");
  let i=0;
  const body=bits.map((b,k)=>{
    if(k===bits.length-1) return b;
    const j=i++, bl=blanks[j];
    if(part.ok[j]) return b+`<span class="bx-fill">${bl.answer}</span>`;
    if(!live) return b+`<span class="bx-fill dim">___</span>`;
    return b+`<input class="bx-in${part.hint[j]?" bad":""}" data-w="${which}" data-b="${j}" value="${bxEsc(part.vals[j])}" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done" aria-label="${which==="first"?"First":"Last"} line, blank ${j+1}" size="${Math.max(10,bl.answer.length+4)}">`;
  }).join("");
  let h=`<div class="bx-line${live?" live":""}${part.ok.every(Boolean)?" done":""}"><span class="bx-tag">${which==="first"?"First line":"Last line"}</span>${body}</div>`;
  if(live){
    const hints=blanks.map((bl,j)=>part.ok[j]||!part.hint[j] ? "" : `<div class="bx-hint" data-b="${j}"><b>Blank ${j+1}:</b> ${part.hint[j]}${part.miss[j]>=3?` <button class="bx-show" data-w="${which}" data-b="${j}">Show me</button>`:""}</div>`).join("");
    h+=`<div class="bx-hints">${hints}</div><div class="bx-row"><button class="btn" id="bxCheckLine" data-w="${which}">Check the ${which} line</button></div>`;
  }
  return h;
}
function bxOrderHTML(L){
  const F=L.framework, run=bossRec(L.id).run, n=F.middle_steps.length, placed=run.order, pool=run.pool.filter(id=>!placed.includes(id));
  const chk=run.check, prob=chk && !chk.valid ? bxProblem(L,placed) : null;
  let h=`<div class="bx-mid"><div class="bx-sub">Put the middle in order. Tap a step to add it below the first line; tap a placed step to take it back.</div><ol class="bx-built">`;
  for(let i=0;i<n;i++){
    const id=placed[i];
    if(!id){ h+=`<li class="slot"><span class="n">${i+1}</span><span class="t">${i===placed.length?"tap a step below":""}</span></li>`; continue; }
    const s=bxStepOf(L,id), bad=prob && prob.id===id;
    h+=`<li class="placed${bad?" bad":""}"><button class="bx-step" data-s="${id}" data-act="back"><span class="n">${i+1}</span><span class="t">${s.text}</span></button>`;
    if(chk && i<n-1) h+= chk.good[i] ? `<span class="bx-join ok" title="R.V. has these two next to each other">⛓ linked</span>` : `<span class="bx-join"></span>`;
    h+=`</li>`;
  }
  h+=`</ol>`;
  if(chk && !chk.valid){
    const s=bxStepOf(L,prob.id), d=bxStepOf(L,prob.need);
    h+=`<div class="bx-msg bad"><b>${chk.credit} of ${chk.total}</b> links match R.V.'s order. But one step is above something it needs: <i>${s.short}</i> uses <i>${d.short}</i>, which comes later. Tap steps to take them back and fix it.</div>`;
    if(run.checks>=2) h+=`<div class="bx-row"><button class="btn ghost" id="bxUseRV">Use R.V.'s order</button></div>`;
  }
  if(pool.length) h+=`<div class="bx-pool" aria-label="Steps to place">${pool.map(id=>`<button class="bx-step" data-s="${id}" data-act="place"><span class="t">${bxStepOf(L,id).text}</span></button>`).join("")}</div>`;
  h+=`<div class="bx-row"><button class="btn" id="bxCheckOrder" ${placed.length<n||(chk&&!chk.valid)?"disabled":""}>Check the order</button>${placed.length?`<button class="btn ghost" id="bxClear">Clear</button>`:""}</div></div>`;
  return h;
}
function bxLicHTML(L){
  const F=L.framework, run=bossRec(L.id).run, order=run.order;
  const cur=run.stage==="license" ? order.find(id=>!(run.lic[id]&&run.lic[id].ok)) : null;
  let h=`<div class="bx-mid">`;
  if(run.stage==="license"){
    const tot=F.middle_steps.length-1;
    h+=`<div class="bx-msg">${run.firstCredit===tot ? "Order: right on the first check." : `Order: <b>${run.firstCredit} of ${tot}</b> links on the first check.`} ${order.join()!==F.middle_steps.map(s=>s.id).join() ? "R.V. wrote them in a different order, but yours works: every step comes after what it needs." : ""}</div>`;
    h+=`<div class="bx-sub">Now say what licenses each step: which definition or theorem makes it legal?</div>`;
  }
  h+=`<ol class="bx-built lic">`;
  order.forEach((id,i)=>{
    const s=bxStepOf(L,id), r=run.lic[id]||{tries:[],ok:false};
    h+=`<li class="placed${id===cur?" cur":""}"><div class="bx-step static"><span class="n">${i+1}</span><span class="t">${s.text}</span></div>`;
    if(r.ok) h+=`<div class="bx-lic ok"><span class="bx-tag">Licensed by</span><span class="ink">${s.licensed_by}</span></div>`;
    else if(id===cur){
      const ord=run.licOrder[id]||(run.licOrder[id]=slipShuffle(s.license_options.length));
      h+=`<div class="bx-chips"><span class="bx-tag">Licensed by…</span>${ord.map(k=>{ const o=s.license_options[k], was=r.tries.includes(k)&&!o.correct;
        return `<button class="opt bx-chip${was?" x":""}" data-s="${id}" data-k="${k}" ${was?"disabled":""}><span class="t">${o.text}</span>${was?`<span class="miss">${o.feedback||""}</span>`:""}</button>`; }).join("")}</div>`;
    }else h+=`<div class="bx-lic wait"><span class="bx-tag">Licensed by</span>?</div>`;
    h+=`</li>`;
  });
  h+=`</ol></div>`;
  return h;
}
function bxWire(L){
  const rec=bossRec(L.id), run=rec.run;
  text.querySelectorAll(".bx-in").forEach(inp=>{
    inp.oninput=()=>{ run[inp.dataset.w].vals[+inp.dataset.b]=inp.value; saveBoss(); };
    inp.onkeydown=e=>{ if(e.key==="Enter"){ e.preventDefault(); bxCheckLine(inp.dataset.w); } };
  });
  $("#bxCheckLine") && ($("#bxCheckLine").onclick=()=>bxCheckLine($("#bxCheckLine").dataset.w));
  text.querySelectorAll(".bx-show").forEach(b=>b.onclick=()=>{ const p=run[b.dataset.w], j=+b.dataset.b; p.ok[j]=true; p.shown[j]=true; p.hint[j]=""; bxAfterLine(b.dataset.w); });
  text.querySelectorAll(".bx-step[data-act]").forEach(b=>b.onclick=()=>bxTapStep(b.dataset.s, b.dataset.act));
  $("#bxCheckOrder") && ($("#bxCheckOrder").onclick=bxCheckOrder);
  $("#bxClear") && ($("#bxClear").onclick=()=>{ run.order=[]; run.check=null; saveBoss(); runBoss(false); });
  $("#bxUseRV") && ($("#bxUseRV").onclick=()=>{ run.order=L.framework.middle_steps.map(s=>s.id); run.check=null; saveBoss(); bxCheckOrder(); });
  text.querySelectorAll(".bx-chip:not(:disabled)").forEach(b=>b.onclick=()=>bxLicense(b.dataset.s, +b.dataset.k, b));
}
function bxCheckLine(which){
  const L=LV, F=L.framework, run=bossRec(L.id).run, part=run[which], blanks=F[which+"_blanks"];
  text.querySelectorAll(`.bx-in[data-w="${which}"]`).forEach(inp=>part.vals[+inp.dataset.b]=inp.value);
  let firstBad=-1;
  blanks.forEach((bl,j)=>{
    if(part.ok[j]) return;
    const v=part.vals[j]||"";
    if(!v.trim()){ part.hint[j]="Fill in this blank."; if(firstBad<0) firstBad=j; return; }
    const r=MORProof.checkBlank(bl,v);
    if(r.ok){ part.ok[j]=true; part.hint[j]=""; }
    else{ part.miss[j]++; part.hint[j]=r.hint; if(firstBad<0) firstBad=j; }
  });
  if(firstBad>=0){
    saveBoss(); Sfx.play("wrong"); runBoss(false);
    const inp=text.querySelector(`.bx-in[data-w="${which}"][data-b="${firstBad}"]`);
    const line=text.querySelector(".bx-line.live"); if(line) replay(line,"shake");
    inp?.focus({preventScroll:true}); inp?.closest(".bx-line")?.scrollIntoView({block:"center",behavior:reduce?"auto":"smooth"});
    return;
  }
  bxAfterLine(which);
}
function bxAfterLine(which){
  const L=LV, run=bossRec(L.id).run;
  if(run[which].ok.every(Boolean)){ run.stage = which==="first" ? "last" : "order"; Sfx.play("right"); }
  saveBoss(); runBoss(false);
  const next = run.stage==="last" ? text.querySelector('.bx-in[data-w="last"]') : run.stage==="order" ? text.querySelector(".bx-mid") : text.querySelector(".bx-in");
  if(next){ if(next.tagName==="INPUT") next.focus({preventScroll:true}); next.scrollIntoView({block:"center",behavior:reduce?"auto":"smooth"}); }
}
function bxTapStep(id, act){
  const run=bossRec(LV.id).run;
  if(act==="place"){ if(!run.order.includes(id)) run.order.push(id); }
  else run.order=run.order.filter(x=>x!==id);
  run.check=null; saveBoss(); Sfx.play("paper"); runBoss(false);
}
function bxCheckOrder(){
  const L=LV, F=L.framework, rec=bossRec(L.id), run=rec.run;
  if(run.order.length<F.middle_steps.length) return;
  const r=MORProof.scoreOrder(F.middle_steps, run.order);
  run.checks++;
  if(run.firstCredit==null) run.firstCredit=r.credit;
  run.check={valid:r.valid, credit:r.credit, total:r.total, good:r.good};
  if(r.valid){ run.stage="license"; Sfx.play("right"); saveBoss(); runBoss(false); text.querySelector(".bx-mid")?.scrollIntoView({block:"start",behavior:reduce?"auto":"smooth"}); return; }
  saveBoss(); Sfx.play("wrong"); runBoss(false);
  text.querySelector(".bx-msg.bad")?.scrollIntoView({block:"center",behavior:reduce?"auto":"smooth"});
}
function bxLicense(id, k, btn){
  const L=LV, F=L.framework, rec=bossRec(L.id), run=rec.run, s=bxStepOf(L,id), o=s.license_options[k];
  const r=run.lic[id]||(run.lic[id]={tries:[],ok:false});
  if(!r.tries.includes(k)) r.tries.push(k);
  if(!o.correct){
    saveBoss(); btn.disabled=true; btn.classList.add("x");
    btn.insertAdjacentHTML("beforeend", scratchSVG()+`<span class="miss">${o.feedback||""}</span>`);
    Sfx.play("wrong"); replay(btn.closest("li"),"shake"); return;
  }
  r.ok=true; saveBoss();
  if(F.middle_steps.every(s=>run.lic[s.id]&&run.lic[s.id].ok)) return bxFinish();
  Sfx.play("right"); runBoss(false);
  text.querySelector(".bx-built li.cur")?.scrollIntoView({block:"center",behavior:reduce?"auto":"smooth"});
}
function bxFinish(){
  const L=LV, F=L.framework, rec=bossRec(L.id), run=rec.run;
  run.stage="done"; rec.done=true; rec.rebuilding=false;
  const sc=bxScore(run,F); rec.last=sc; if(bxSum(sc)>bxSum(rec.best)) rec.best=sc;
  rec.builtAt=Date.now(); saveBoss();
  Object.keys(L.gaps).forEach(g=>{ S.solved[key(g)]=true; if(L.gaps[g].monster) S.monsters[L.id+"|"+g+"|m"]=true; });
  save(); savePM();
  Sfx.play("done");
  renderLevel(true);
  window.scrollTo({top:0,behavior:reduce?"auto":"smooth"});
  pqOffer("page",4200);
}
/* The banner above the finished proof. */
function bxBannerHTML(L){
  const r=BOSSES[L.id], s=r && r.last;
  if(!s) return `<div class="bx-banner"><div class="bx-sum">You won this page circle by circle. R.V.'s star means you can also build it from its frame.</div><button class="btn ghost" id="bxRebuild">Build the proof from scratch</button></div>`;
  const line=(a,b,t)=>`<li><b>${a}/${b}</b> ${t}</li>`;
  return `<div class="bx-banner"><div class="bx-sum">You built ${L.no} yourself. Here it is in full, with R.V.'s notes.</div>
    <ul class="bx-score">${line(s.lines,s.linesOf,"blanks right the first time")}${line(s.order,s.orderOf,"order links on the first check")}${line(s.lic,s.licOf,"licenses right the first time")}</ul>
    ${r.best && bxSum(r.best)>bxSum(s) ? `<div class="bx-best">Best so far: ${bxSum(r.best)} of ${s.linesOf+s.orderOf+s.licOf}.</div>` : ""}
    <button class="btn ghost" id="bxRebuild">Rebuild the proof</button></div>`;
}
function bxRebuild(){ const rec=bossRec(LV.id); rec.run=bxFresh(); rec.rebuilding=true; saveBoss(); renderLevel(true); }
function bxErase(){ delete BOSSES[LV.id]; saveBoss(); }
