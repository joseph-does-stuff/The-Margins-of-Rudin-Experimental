// Checks that content/ch1.json, read through js/content.js, gives back exactly the original LEVELS
// (same values and same key order, which the engine relies on for circle order).
const fs = require('fs');
const C = require('../js/content.js');
const orig = JSON.parse(fs.readFileSync(__dirname + '/levels_original.json', 'utf8'));
// Deliberate Prompt 4 fix: the 1.21 page printed "Then then" and "impossible impossible" (circle word + body word).
{ const b = orig.find(l => l.id === 'c1-1-21'); b.gaps.r5.w = 'Then';
  b.proof = b.proof.map(p => p.replace('Then [[r5]] (y + h)', '[[r5]] (y + h)').replace('That is [[r6]] impossible.', 'That is [[r6]].'));
  b.gaps.r4.ink = b.gaps.r4.ink.replace('and [[r4b]] each is', 'and [[r4b]] is');
  const m = orig.find(l => l.id === 'c1-1-15'); m.proof = m.proof.map(p => p.replace('[[m1]] exists because', '[[m1]] because'));
  const a = orig.find(l => l.id === 'c1-1-20'); a.gaps.a4.ink = a.gaps.a4.ink.replace('because [[a5]] m + 1', '[[a5]] m + 1'); }
const doc = JSON.parse(fs.readFileSync(__dirname + '/../content/ch1.json', 'utf8'));
const docAll = { ...doc, pages: doc.pages.filter(p => p.kind !== 'SLIP').map(p => { const { hidden, ...q } = p; return q; }) };
const got = C.chapterToLevels(docAll).map(({ framework, ...l }) => ({ ...l, gaps: Object.fromEntries(Object.entries(l.gaps).map(([k, g]) => { const { misc, ...rest } = g; return [k, rest]; })) }));
// Every wrong option carries a misconception id that exists in the map.
const M = doc.misconceptions || {};
let tagged = 0;
for (const l of C.chapterToLevels(docAll)) for (const g of Object.values(l.gaps)) g.opts.forEach((o, i) => { if (!o[1]) { const t = g.misc && g.misc[i]; if (!t || !M[t] || !M[t].label) { console.log('untagged or unlabeled:', l.id, g.w, i, t); process.exit(1); } tagged++; } });
console.log('misconception tags OK:', tagged, 'wrong options,', Object.keys(M).length, 'labelled IDs');
// Field order inside a circle doesn't matter to the engine; circle order and everything else does.
const sortKeys = o => Object.fromEntries(Object.keys(o).sort().map(k => [k, o[k]]));
const canon = L => JSON.stringify(L.map(l => sortKeys({ ...l, gapOrder: Object.keys(l.gaps), gaps: Object.fromEntries(Object.entries(l.gaps).map(([k, g]) => [k, Object.fromEntries(Object.keys(g).sort().map(f => [f, g[f]]))])) })));
const a = canon(orig), b = canon(got);
if (a === b) { console.log('round trip OK:', got.length, 'pages, identical'); }
else {
  for (let i = 0; i < orig.length; i++) if (canon([orig[i]]) !== canon([got[i]])) {
    const x = canon([orig[i]]), y = canon([got[i]]); let k = 0; while (x[k] === y[k]) k++;
    console.log('DIFF page', orig[i].id, '\n orig:', x.slice(Math.max(0, k - 80), k + 120), '\n  got:', y.slice(Math.max(0, k - 80), k + 120)); break;
  }
  process.exit(1);
}
// Unknown kinds must not throw.
const odd = C.chapterToLevels({ chapter: 1, pages: [{ id: 'c1-slip-1', kind: 'SLIP', title: 'Find R.V.’s slip', proof_lines: [] }, { id: 'x', kind: 'WHATEVER' }, { id: 'y' }, null] });
console.log('unknown kinds ->', odd.map(l => l.id + ':' + l.role + (l.soon ? '(soon)' : '')).join(', '));

const slips = C.chapterToLevels(doc).filter(l => l.role === 'Slip');
console.log('slip levels:', slips.map(l => l.id + ' (' + l.slip.lines.length + ' lines, flaw on ' + l.slip.flaw + ', ' + l.slip.flawType + (l.bonus ? ', bonus' : '') + ')').join('; '));
console.log('playback hidden:', !C.chapterToLevels(doc).some(l => l.id === 'c1-j-playback'));
