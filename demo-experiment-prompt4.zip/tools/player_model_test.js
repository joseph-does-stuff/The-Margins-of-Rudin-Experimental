// Unit tests for the Monster Deck scheduler (js/player-model.js). Run: node tools/player_model_test.js
const assert = require('assert');
const P = require('../js/player-model.js');
const D = P.DAY, T0 = Date.UTC(2026, 9, 8, 15);
let n = 0; const test = (name, f) => { f(); n++; console.log('ok -', name); };
const wrong = (m, t, misc = 'M-SUP-MAX', circle = 'g1', option = 1, level = 'c1-1-1') => P.recordWrong(m, { level, circle, option, misc }, t);

test('a wrong pick adds a hit and a card due in 1 day', () => {
  const m = P.empty(); const c = wrong(m, T0);
  assert.strictEqual(m.misconceptions['M-SUP-MAX'].hits, 1);
  assert.strictEqual(c.due, T0 + D);
  assert.deepStrictEqual(P.dueCards(m, T0 + D - 1), []);
  assert.strictEqual(P.dueCards(m, T0 + D).length, 1);
});
test('untagged options are ignored', () => {
  const m = P.empty(); assert.strictEqual(wrong(m, T0, null), null); assert.strictEqual(m.retrievalQueue.length, 0);
});
test('the same circle missed again is one card, reset to 1 day', () => {
  const m = P.empty(); wrong(m, T0); wrong(m, T0 + 5 * D);
  assert.strictEqual(m.retrievalQueue.length, 1); assert.strictEqual(m.retrievalQueue[0].due, T0 + 6 * D);
  assert.strictEqual(m.misconceptions['M-SUP-MAX'].hits, 2);
});
test('correct answers step 1 → 3 → 7 → 21 days (with banishing switched off)', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId; let t = T0 + D; const gaps = [];
  for (let i = 0; i < 4; i++) { m.misconceptions['M-SUP-MAX'].streak = -10; const r = P.answer(m, id, true, t); gaps.push(r.days); t = m.retrievalQueue[0].due; }
  assert.deepStrictEqual(gaps, [3, 7, 21, 21]);
});
test('a miss resets the card to 1 day and counts as a hit', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId;
  P.answer(m, id, true, T0 + D); const r = P.answer(m, id, false, T0 + 4 * D, 2);
  assert.strictEqual(r.outcome, 'miss'); assert.strictEqual(m.retrievalQueue[0].due, T0 + 5 * D);
  assert.strictEqual(m.retrievalQueue[0].step, 0); assert.strictEqual(m.misconceptions['M-SUP-MAX'].hits, 2);
  assert.strictEqual(m.misconceptions['M-SUP-MAX'].streak, 0);
});
test('two correct in a row, a day or more apart, banish the monster', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId;
  assert.strictEqual(P.answer(m, id, true, T0 + D).outcome, 'next');
  const r = P.answer(m, id, true, T0 + 4 * D);
  assert.strictEqual(r.outcome, 'banished'); assert.strictEqual(m.misconceptions['M-SUP-MAX'].banished, true);
  assert.strictEqual(m.retrievalQueue.length, 0); assert.strictEqual(m.bestiary.length, 1);
});
test('two correct the same day count once', () => {
  const m = P.empty(); wrong(m, T0, 'M-INEQ', 'g1'); wrong(m, T0, 'M-INEQ', 'g2');
  const [a, b] = m.retrievalQueue.map(c => c.cardId);
  P.answer(m, a, true, T0 + D); const r = P.answer(m, b, true, T0 + D + 1000);
  assert.strictEqual(r.outcome, 'next'); assert.strictEqual(m.misconceptions['M-INEQ'].streak, 1);
});
test('a miss between two correct answers breaks the streak', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId;
  P.answer(m, id, true, T0 + D); P.answer(m, id, false, T0 + 4 * D); const r = P.answer(m, id, true, T0 + 5 * D);
  assert.strictEqual(r.outcome, 'next');
});
test('banishing retires every card of that monster, and others stay', () => {
  const m = P.empty(); wrong(m, T0, 'M-INEQ', 'g1'); wrong(m, T0, 'M-INEQ', 'g2'); wrong(m, T0, 'M-ALG-SLIP', 'g3');
  const a = m.retrievalQueue[0].cardId; P.answer(m, a, true, T0 + D); P.answer(m, a, true, T0 + 4 * D);
  assert.deepStrictEqual(m.retrievalQueue.map(c => c.misc), ['M-ALG-SLIP']);
  assert.strictEqual(m.bestiary.filter(c => c.misc === 'M-INEQ').length, 2);
});
test('banished monsters never come up due, but a new mistake brings them back', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId;
  P.answer(m, id, true, T0 + D); P.answer(m, id, true, T0 + 4 * D);
  assert.deepStrictEqual(P.dueCards(m, T0 + 100 * D), []);
  wrong(m, T0 + 50 * D);
  assert.strictEqual(m.misconceptions['M-SUP-MAX'].banished, false);
  assert.strictEqual(m.retrievalQueue.length, 1); assert.strictEqual(m.bestiary.length, 0);
});
test('a dispute removes the card, its hits, and that tag from then on', () => {
  const m = P.empty(); wrong(m, T0); const id = m.retrievalQueue[0].cardId;
  assert.strictEqual(P.dispute(m, id, T0 + D, 'I misread the question'), true);
  assert.strictEqual(m.retrievalQueue.length, 0); assert.strictEqual(m.misconceptions['M-SUP-MAX'], undefined);
  assert.strictEqual(m.disputes[0].note, 'I misread the question');
  assert.strictEqual(wrong(m, T0 + 2 * D), null);                 // same option: tag no longer counts
  assert.notStrictEqual(wrong(m, T0 + 2 * D, 'M-SUP-MAX', 'g1', 2), null); // another option still does
});
test('normalize repairs missing or broken saved data', () => {
  const m = P.normalize({ circlesDone: 3, retrievalQueue: 'oops' });
  assert.strictEqual(m.circlesDone, 3); assert.deepStrictEqual(m.retrievalQueue, []); assert.deepStrictEqual(m.misconceptions, {});
  assert.deepStrictEqual(P.normalize(null), P.empty());
});
console.log(n, 'tests passed');
