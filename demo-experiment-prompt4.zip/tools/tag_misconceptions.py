"""Part A: tag every wrong option in content/ch1.json with a misconception ID (hand-assigned below)."""
import json
LABELS = {
 # given taxonomy
 'M-SUP-MAX': 'supremum = maximum (the sup must be a largest element, or lie in the set)',
 'M-Q-ORDER': 'reversed quantifier order (δ or N chosen before ε)',
 'M-CONVERSE': 'confusing a statement with its converse',
 'M-IMG-LIMIT': 'limit as unreachable barrier / dynamic-only image',
 'M-REP-UNIQ': 'assuming representations are unique (e.g. fractions)',
 'M-ASSUME-PROVE': 'assuming what must be proved',
 'M-EX-MASQ': 'example masquerading as proof',
 'M-WLOG': "unjustified 'WLOG' / hidden existence assumption",
 # added for Chapter 1
 'M-NEGATE': 'negating a statement wrongly ("not an upper bound" read as "a lower bound", "not every" as "none")',
 'M-SOME-ALL': '"most" or "some" accepted where the definition says "every"',
 'M-REDUNDANT': 'treating a clause of a definition or axiom as redundant',
 'M-JUST-CONVENTION': 'calling a forced requirement a mere convention',
 'M-CONCRETE': 'reading an abstract structure as ordinary numbers',
 'M-FINITE': 'carrying finite intuition to infinite sets, or tying a rule to finiteness',
 'M-VACUOUS': 'mishandling vacuous truth (statements about the empty set)',
 'M-INFINITY-NUMBER': 'treating ∞ as a number',
 'M-BOUND-IN-SET': 'thinking a bound must lie in (or outside) the set',
 'M-BOUND-MONO': 'getting the direction of bounds wrong (numbers above an upper bound are upper bounds; "least" restricts what lies below)',
 'M-EXTREMAL': 'taking any witness when the least (or greatest) one is needed',
 'M-HYPOTHESIS': 'using a result without its hypotheses (nonempty, bounded above, positive, nonzero)',
 'M-WRONG-TOOL': 'citing the wrong axiom or theorem for a step',
 'M-TRUE-NOT-REASON': "a true fact that isn't the reason for the step",
 'M-STEP-ORDER': 'using the steps of an argument in the wrong order',
 'M-INEQ': 'mishandled inequality (wrong direction, lower bound for upper, subtracting or chaining inequalities)',
 'M-ALG-SLIP': 'algebra slip (signs, expansions, (u − v)² ≠ u² − v², √ is not additive)',
 'M-COMPLEX-AS-REAL': 'treating complex numbers like reals (u² ≥ 0, z w̄ = z̄ w, componentwise products)',
 'M-DEF-MISREAD': 'misreading what a definition says',
 'M-FALSE-ALARM': 'flagging a correct statement as the mistake',
}
TAGS = """
c1-1-1 g1 1 M-REP-UNIQ | 2 M-TRUE-NOT-REASON
c1-1-1 g2 1 M-CONVERSE | 2 M-ASSUME-PROVE
c1-1-1 g3 1 M-ALG-SLIP | 2 M-ALG-SLIP | 3 M-ASSUME-PROVE
c1-1-1 g4 1 M-TRUE-NOT-REASON | 2 M-INEQ
c1-j-1-5 j1 1 M-REDUNDANT | 2 M-DEF-MISREAD | 3 M-DEF-MISREAD
c1-j-1-5 j2 1 M-REDUNDANT | 2 M-CONCRETE | 3 M-FINITE
c1-j-1-7 k1 1 M-BOUND-IN-SET | 2 M-BOUND-IN-SET | 3 M-DEF-MISREAD
c1-j-1-7 k2 1 M-SOME-ALL | 2 M-FINITE | 3 M-NEGATE
c1-j-1-8 s1 1 M-REDUNDANT | 2 M-SUP-MAX | 3 M-FINITE
c1-j-1-8 s2 1 M-DEF-MISREAD | 2 M-SUP-MAX | 3 M-NEGATE
c1-j-1-10 p1 1 M-VACUOUS | 2 M-VACUOUS | 3 M-VACUOUS
c1-j-1-10 p2 1 M-FINITE | 2 M-SUP-MAX | 3 M-DEF-MISREAD
c1-j-1-10 p3 1 M-SUP-MAX | 2 M-CONCRETE | 3 M-CONCRETE
c1-1-11 a1 1 M-ASSUME-PROVE | 2 M-INEQ | 3 M-BOUND-IN-SET
c1-1-11 a2 1 M-HYPOTHESIS | 2 M-ASSUME-PROVE | 3 M-HYPOTHESIS
c1-1-11 a3 1 M-BOUND-MONO | 2 M-ASSUME-PROVE | 3 M-ASSUME-PROVE
c1-1-11 a4 1 M-BOUND-MONO | 2 M-BOUND-MONO | 3 M-BOUND-IN-SET
c1-j-1-12 f1 1 M-INFINITY-NUMBER | 2 M-JUST-CONVENTION | 3 M-TRUE-NOT-REASON
c1-j-1-12 f2 1 M-REDUNDANT | 2 M-CONCRETE | 3 M-CONCRETE
c1-j-1-12 f3 1 M-REDUNDANT | 2 M-DEF-MISREAD | 3 M-JUST-CONVENTION
c1-1-14 q1 1 M-WRONG-TOOL | 2 M-WRONG-TOOL | 3 M-WRONG-TOOL
c1-1-15 m1 1 M-HYPOTHESIS | 2 M-ASSUME-PROVE | 3 M-WRONG-TOOL
c1-1-16 u1 1 M-WRONG-TOOL | 2 M-WRONG-TOOL | 3 M-WRONG-TOOL
c1-1-16 u2 1 M-WRONG-TOOL | 2 M-ASSUME-PROVE | 3 M-ASSUME-PROVE
c1-j-1-17 o1 1 M-REDUNDANT | 2 M-CONCRETE | 3 M-FINITE
c1-j-1-17 o2 1 M-REDUNDANT | 2 M-DEF-MISREAD | 3 M-CONVERSE
c1-1-18 o1 1 M-ALG-SLIP | 2 M-ASSUME-PROVE | 3 M-WRONG-TOOL
c1-1-18 o2 1 M-WRONG-TOOL | 2 M-WRONG-TOOL | 3 M-ASSUME-PROVE
c1-1-20 a1 1 M-HYPOTHESIS | 2 M-HYPOTHESIS | 3 M-SUP-MAX
c1-1-20 a2 1 M-BOUND-IN-SET | 2 M-BOUND-MONO | 3 M-INEQ
c1-1-20 a3 1 M-NEGATE | 2 M-ASSUME-PROVE | 3 M-SUP-MAX
c1-1-20 a4 1 M-NEGATE | 2 M-SUP-MAX | 3 M-INEQ
c1-1-20 a5 1 M-DEF-MISREAD | 2 M-DEF-MISREAD | 3 M-DEF-MISREAD
c1-1-20 b1 1 M-ALG-SLIP | 2 M-INEQ | 3 M-WLOG
c1-1-20 b2 1 M-EXTREMAL | 2 M-EXTREMAL | 3 M-EXTREMAL
c1-1-21 r1 1 M-HYPOTHESIS | 2 M-WRONG-TOOL | 3 M-ASSUME-PROVE
c1-1-21 r2 1 M-WLOG | 2 M-TRUE-NOT-REASON | 3 M-WLOG
c1-1-21 r3 1 M-WLOG | 2 M-INEQ | 3 M-WLOG
c1-1-21 r4 1 M-INEQ | 2 M-INEQ | 3 M-ALG-SLIP
c1-1-21 r4b 1 M-INEQ | 2 M-WLOG | 3 M-INEQ
c1-1-21 r5 1 M-HYPOTHESIS | 2 M-STEP-ORDER | 3 M-WRONG-TOOL
c1-1-21 r6 1 M-INEQ | 2 M-BOUND-MONO | 3 M-BOUND-MONO
c1-1-21 r7 1 M-ALG-SLIP | 2 M-ALG-SLIP | 3 M-WLOG
c1-1-21 r8 1 M-BOUND-IN-SET | 2 M-BOUND-MONO | 3 M-EXTREMAL
c1-1-21-cor c1 1 M-ASSUME-PROVE | 2 M-WRONG-TOOL | 3 M-WRONG-TOOL
c1-j-1-23 e1 1 M-INFINITY-NUMBER | 2 M-SUP-MAX | 3 M-SUP-MAX
c1-j-1-23 e2 1 M-INFINITY-NUMBER | 2 M-DEF-MISREAD | 3 M-INFINITY-NUMBER
c1-j-1-24 c1 1 M-DEF-MISREAD | 2 M-DEF-MISREAD | 3 M-JUST-CONVENTION
c1-j-1-24 c2 1 M-JUST-CONVENTION | 2 M-JUST-CONVENTION | 3 M-DEF-MISREAD
c1-1-25 z1 1 M-ALG-SLIP | 2 M-COMPLEX-AS-REAL | 3 M-WRONG-TOOL
c1-j-1-30 z1 1 M-ALG-SLIP | 2 M-DEF-MISREAD | 3 M-DEF-MISREAD
c1-j-1-30 z2 1 M-COMPLEX-AS-REAL | 2 M-DEF-MISREAD | 3 M-ALG-SLIP
c1-1-31 k1 1 M-ALG-SLIP | 2 M-ASSUME-PROVE | 3 M-ASSUME-PROVE
c1-1-31 k2 1 M-ALG-SLIP | 2 M-ASSUME-PROVE | 3 M-ALG-SLIP
c1-1-33 t1 1 M-WLOG | 2 M-ALG-SLIP | 3 M-ALG-SLIP
c1-1-33 t2 1 M-COMPLEX-AS-REAL | 2 M-CONVERSE | 3 M-WRONG-TOOL
c1-1-33 t3 1 M-COMPLEX-AS-REAL | 2 M-INEQ | 3 M-INEQ
c1-1-33 t4 1 M-HYPOTHESIS | 2 M-HYPOTHESIS | 3 M-ASSUME-PROVE
c1-1-35 s1 1 M-DEF-MISREAD | 2 M-CONVERSE | 3 M-DEF-MISREAD
c1-1-35 s2 1 M-COMPLEX-AS-REAL | 2 M-TRUE-NOT-REASON | 3 M-ASSUME-PROVE
c1-1-35 s3 1 M-DEF-MISREAD | 2 M-ALG-SLIP | 3 M-ALG-SLIP
c1-1-35 s4 1 M-HYPOTHESIS | 2 M-INEQ | 3 M-TRUE-NOT-REASON
c1-j-1-36 r1 1 M-DEF-MISREAD | 2 M-DEF-MISREAD | 3 M-DEF-MISREAD
c1-j-1-36 r2 1 M-EX-MASQ | 2 M-DEF-MISREAD | 3 M-DEF-MISREAD
c1-1-37 e1 1 M-ASSUME-PROVE | 2 M-INEQ | 3 M-WRONG-TOOL
c1-1-37 e2 1 M-ALG-SLIP | 2 M-ALG-SLIP | 3 M-TRUE-NOT-REASON
c1-j-playback p1 1 M-FALSE-ALARM | 2 M-FALSE-ALARM | 3 M-FALSE-ALARM
c1-j-playback p2 1 M-IMG-LIMIT | 2 M-SUP-MAX | 3 M-EXTREMAL
"""
tags = {}
for line in TAGS.strip().splitlines():
    pid, cid, rest = line.split(' ', 2)
    for part in rest.split('|'):
        k, t = part.split()
        assert t in LABELS, t
        tags[(pid, cid, int(k))] = t

d = json.load(open('content/ch1.json', encoding='utf-8'))
used, missing = set(), []
for p in d['pages']:
    circles = p.get('circles') or [x for x in p.get('dialogue', []) if x['speaker'] == 'choice']
    for c in circles:
        cid = c.get('id') or c.get('circle')
        for k, o in enumerate(c['options']):
            if o['correct']:
                o.pop('misconception', None); continue
            t = tags.get((p['id'], cid, k))
            if not t: missing.append((p['id'], cid, k)); continue
            o['misconception'] = t; used.add((p['id'], cid, k))
assert not missing, missing
assert used == set(tags), set(tags) - used
old = d.get('misconceptions', {})
d['misconceptions'] = {k: {**old.get(k, {}), 'label': v} for k, v in LABELS.items()}
json.dump(d, open('content/ch1.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
from collections import Counter
print(len(used), 'wrong options tagged with', len({tags[k] for k in used}), 'IDs')
for t, n in Counter(tags.values()).most_common(): print(f'{n:3d} {t}')
