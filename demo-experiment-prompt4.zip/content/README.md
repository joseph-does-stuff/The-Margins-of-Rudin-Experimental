# Chapter content files

The game reads one file per chapter (`content/ch1.json`, …) at startup. `js/content.js` turns each page
into the level object the engine renders; `index.html` no longer contains any level text.

## Schema (as used by ch1.json)

```
{ "chapter": 1, "title": "...", "pages": [ PAGE, ... ], "misconceptions": { "M-ID": {"label": "..."} } }
```

Every PAGE has `id` (the save key; never change it), `rudin`, `kind`, `title`, `type` (Theorem, Definition…),
`statement`, `body_html` and `note`.

- `body_html`: the proof as `<p>` paragraphs. Each circle is `<span class='gap' data-circle='g1'>circled words</span>`.
- **HUNT / QUICK / BOSS**: `circles: [{id, word, label, question, options, monster?}]`
  - option: `{text, correct: true, margin_note}` or `{text, correct: false, feedback, misconception}`
  - `misconception` is an ID from the chapter's `misconceptions` map; every wrong option has one
  - `label` is R.V.'s pencil label for the circle ("why?", "isn't this obvious?")
  - `monster: {name, text}` is the card added to the monster deck
- **READ**: no circles; `note` is shown under the statement.
- **JUNE / PLAYBACK**: `dialogue` alternates `{"speaker": "june", "text": question}` and
  `{"speaker": "choice", circle, word, label, options}`; the correct option carries `june_reply` and `margin_note`.
  Also `before` (page it comes before), `terms`, `open_lines`, `close_lines`, `your_words_prompt` (null for now).
- **SLIP**: a whole argument with exactly one flawed line. Fields: `statement`, `intro`, `who` ("rv" or "june"),
  `proof_lines: [{n, text, clean_note}]`, `flaw_line`, `flaw_type` (a misconception ID with `short`/`plain` names),
  `flaw_note`, `type_options: [{id, feedback}]` (4, the right one first), `fix_options: [{text, correct, feedback}]` (3),
  `bonus` (locked until the chapter's other pages are done; not counted in chapter progress).
  Stars: ★ find the line, ★ name the flaw on the first try, ★ pick the fix on the first try. Tapping a clean line
  costs nothing. Best stars are saved under `margins-of-rudin-demo-slips`.
- **FOUNDRY, or any kind the engine doesn't know** (or a SLIP missing its lines or fix): shown as a "coming soon" page
  that doesn't count toward progress and can't be marked done. Nothing crashes.
- `hidden: true` keeps a page in the file but out of the game (the old chat-style sup playback, replaced by the SLIP bonus).

Differences from the planning schema, to keep the demo identical:
- `PLAYBACK` is its own kind (June explains to Teo, with one slip).
- The Ch. 1 boss (1.21) keeps its 9 `circles` (they hold R.V.'s margin notes for the finished proof) and adds `framework` (below).
- Circle fields `word`, `label`, `monster` and page fields `type`, `statement`, `note` were added; the demo uses them.
- `misconceptions` holds the labels for every ID used. Chapter 1 uses 27 of the 28 IDs (M-Q-ORDER waits for ε–δ in Ch. 4).

## Tools
- `python3 tools/migrate_ch1.py tools/index.original.html` regenerates ch1.json from the old single-file demo.
- `node tools/roundtrip_test.js` checks that ch1.json reproduces the old level data exactly.

## Monster Deck (spaced retrieval)
- `js/player-model.js`: the scheduler, pure functions with no DOM or storage (tests: `node tools/player_model_test.js`).
- Saved in localStorage under `margins-of-rudin-demo-player`:
  `{circlesDone, misconceptions: {id: {hits, banished, streak, lastCorrect, banishedAt}}, retrievalQueue: [{cardId, due, …}], bestiary, disputes, untagged}`.
- A wrong pick on a tagged option adds a hit and queues that circle for 1 day later. Each correct pop-quiz answer
  moves it 1 → 3 → 7 → 21 days; a miss resets it to 1 day. Two correct answers in a row for the same misconception,
  at least a day apart, banish it to the bestiary. A new mistake of that kind brings it back.
- "That wasn't my mistake" removes the card and its hits, stops that option's tag counting, and logs the note.
- R.V.'s pop quiz is offered when the app opens and between pages whenever cards are due; it's also in the menu.
- `python3 tools/tag_misconceptions.py` re-applies the hand-assigned tags.

- `python3 tools/add_slips.py` (re)writes the three Chapter 1 SLIP levels and the plain names of the flaw types. Run it after `tag_misconceptions.py`.

## BOSS pages: building the proof (`framework`)
A BOSS page with a `framework` is played in four stages before the full proof appears:
1. **First line**, fill in the blanks. 2. **Last line**, fill in the blanks. 3. **Order the middle**, tap-to-order.
4. **Licenses**, pick the definition or theorem that makes each step legal (3 options per step).
Then every circle on the page is marked solved, so the proof renders with R.V.'s notes and joins Theorems won.

```
"framework": {
  "intro": "…",
  "first_line_blank": "Let x > 0 be a ___, and let n be a ___. …",   // one ___ per blank
  "first_line_answer": ["real number", "positive integer"],          // shown in ink once a blank is right
  "first_blanks": [{"answer": "real number",
                    "accept": ["^…$"],                 // regexes, tested against the normalized input
                    "hints": [{"match": "…", "text": "What kind of object is x here? …"}],
                    "hint": "fallback hint"}, …],
  "last_line_blank": "…", "last_line_answer": […], "last_blanks": […],
  "middle_steps": [{"id": "s1", "short": "powers keep order (uniqueness)", "after": [],   // steps it depends on
                    "text": "…", "licensed_by": "…",
                    "license_options": [{"text": "…", "correct": true}, {"text": "…", "correct": false, "feedback": "…"}, …]}]
}
```
- Matching (`js/proof-framework.js`, tests: `node tools/proof_framework_test.js`) lowercases the input and rewrites
  equivalent forms before testing the `accept` regexes: ≥ / "at least" / "greater than or equal to" → `>=`,
  "greater than" → `>`, "zero" → 0, "to the n" / ⁿ → `^n`, a leading a/an/the is dropped. A wrong answer gets the first
  matching `hints` entry, else `hint`. After 3 misses on a blank, "Show me" fills it in (no first-try credit).
- Order: any order where every step comes after everything in its `after` list is accepted with full credit.
  Otherwise the score is the number of adjacent pairs that match the listed order (R.V.'s), each pair one link, and the
  player is told which step sits above something it needs. After two failed checks, "Use R.V.'s order" appears.
- Score (shown above the finished proof): blanks right the first time, order links on the first check, licenses right
  the first time. Saved in localStorage under `margins-of-rudin-demo-boss` as `{id: {done, best, last, run}}`.
- "Rebuild the proof" replays the stages without taking the theorem out of Theorems won. "Erase this page" does both.
- Players who finished the 1.21 circles before this format see the full proof and a "Build the proof from scratch" button.
- `python3 tools/add_boss_framework.py` (re)writes the 1.21 framework; `python3 tools/fix_doubled_words.py` fixes three
  doubled words in the old text (1.15 "exists exists", 1.20 "because because", 1.21 "each each").
