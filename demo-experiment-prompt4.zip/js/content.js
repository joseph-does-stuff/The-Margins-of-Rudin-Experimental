/* Chapter content loader for The Margins of Rudin.
   Reads chapter files (content/chN.json, see the schema in content/README.md) and turns each page into
   the level object the game engine renders. Kinds the engine doesn't know yet (SLIP, FOUNDRY, anything new)
   never crash the app: they become a "coming soon" page that doesn't count toward progress. */
(function (root) {
  const ROLE = { HUNT: 'Hunt', QUICK: 'Quick', READ: 'Read', BOSS: 'Boss', JUNE: 'June', PLAYBACK: 'Playback', SLIP: 'Slip' };

  // body_html -> proof paragraphs with [[circle]] markers, plus the circled words.
  function parseBody(html) {
    const words = {}, proof = [];
    const paras = (html || '').match(/<p>[\s\S]*?<\/p>/g) || [];
    for (const p of paras) {
      proof.push(p.slice(3, -4).replace(/<span class='gap' data-circle='(\w+)'>([\s\S]*?)<\/span>/g, (m, id, w) => { words[id] = w; return `[[${id}]]`; }));
    }
    return { proof, words };
  }

  function toGap(c, word) {
    const g = { w: word != null ? word : c.word, q: c.question, opts: [], ink: '', rv: c.label, misc: [] };
    for (const o of c.options || []) {
      if (o.correct) { g.opts.push([o.text, 1, '']); g.ink = o.margin_note || ''; if (o.june_reply != null) g.back = o.june_reply; g.misc.push(null); }
      else { g.opts.push([o.text, 0, o.feedback || '']); g.misc.push(o.misconception || null); }
    }
    // Keep the engine's key order (w, q, opts, ink, rv, back, monster).
    const out = { w: g.w, q: g.q, opts: g.opts, ink: g.ink, rv: g.rv };
    if ('back' in g) out.back = g.back;
    if (c.monster) out.monster = [c.monster.name, c.monster.text];
    if (g.misc.some(Boolean)) out.misc = g.misc;   // misconception id per option (null for the right one)
    return out;
  }

  function comingSoon(p, ch) {
    return { no: p.rudin || '—', type: 'Coming soon', name: p.title || 'Coming soon', role: 'Read', soon: true,
      stmt: 'R.V. hasn’t filled in this page yet.', proof: [], gaps: {}, note: '', id: p.id, ch };
  }

  function pageToLevel(p, ch) {
    const role = ROLE[String(p.kind || '').toUpperCase()];
    if (!role) return comingSoon(p, ch);
    if (role === 'Slip') return slipToLevel(p, ch);
    try {
      const { proof, words } = parseBody(p.body_html);
      const gaps = {};
      if (role === 'June' || role === 'Playback') {
        const dlg = p.dialogue || [];
        for (let i = 0; i < dlg.length; i++) {
          const d = dlg[i];
          if (d.speaker !== 'choice') continue;
          const asked = dlg[i - 1] && dlg[i - 1].speaker === 'june' ? dlg[i - 1].text : '';
          gaps[d.circle] = toGap({ ...d, question: asked }, words[d.circle]);
        }
      } else {
        for (const c of p.circles || []) gaps[c.id] = toGap(c, words[c.id]);
      }
      const l = { no: p.rudin, type: p.type, name: p.title, role, stmt: p.statement || '', proof, gaps, note: p.note == null ? null : p.note, id: p.id, ch };
      if (role === 'June' || role === 'Playback') {
        if ('before' in p) l.before = p.before;
        if ('terms' in p) l.terms = p.terms;
        if ('open_lines' in p) l.open = p.open_lines;
        if ('close_lines' in p) l.close = p.close_lines;
      }
      if (role === 'Boss' && p.framework && Array.isArray(p.framework.middle_steps)) l.framework = p.framework;
      return l;
    } catch (e) {
      console.warn('Could not read page', p && p.id, e);
      return comingSoon(p, ch);
    }
  }

  /* SLIP: a whole argument with exactly one flawed line. Find the line, name the flaw, pick the fix. */
  function slipToLevel(p, ch) {
    const lines = Array.isArray(p.proof_lines) ? p.proof_lines.filter(l => l && l.text) : [];
    const fixes = (p.fix_options || []).map((f, i) => typeof f === 'string' ? { text: f, correct: i === (p.fix_answer || 0) } : f);
    const types = (p.type_options || [{ id: p.flaw_type }]).map(t => typeof t === 'string' ? { id: t } : t);
    if (!lines.length || !lines.some(l => l.n === p.flaw_line) || !fixes.some(f => f.correct)) return comingSoon(p, ch);
    return { no: p.rudin || '—', type: 'Slip', name: p.title, role: 'Slip', stmt: p.statement || '', proof: [], gaps: {}, note: p.note == null ? null : p.note,
      id: p.id, ch, bonus: !!p.bonus,
      slip: { who: p.who || 'rv', intro: p.intro || 'One line is wrong. Tap it.', lines, flaw: p.flaw_line, flawType: p.flaw_type, flawNote: p.flaw_note || '',
              types, fixes, clean: p.clean_default || "R.V. double-checked that line — it's clean." } };
  }

  function chapterToLevels(doc) {
    const ch = doc.chapter;
    return (doc.pages || []).filter(p => p && p.id && !p.hidden).map(p => pageToLevel(p, ch));
  }

  // Misconception labels from every loaded chapter file: {id: {label}}.
  const MISC = {};
  function addMisconceptions(doc) { Object.assign(MISC, (doc && doc.misconceptions) || {}); return MISC; }

  root.MORContent = { chapterToLevels, pageToLevel, addMisconceptions, misconceptions: MISC };
  if (typeof module !== 'undefined') module.exports = root.MORContent;
})(typeof window !== 'undefined' ? window : globalThis);
