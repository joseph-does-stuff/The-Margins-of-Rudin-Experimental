/* Player model and spaced-retrieval scheduler for the Monster Deck.
   Pure functions: no DOM, no storage, no clock. Every function takes the model and `now` (ms) and returns
   a result, so the scheduling can be unit-tested in Node (tools/player_model_test.js).

   Model (stored in localStorage by the game):
   {
     v: 1,
     circlesDone: number,
     misconceptions: { [id]: { hits, banished, streak, lastCorrect, banishedAt } },
     retrievalQueue: [ { cardId, level, circle, option, misc, step, due, misses, added } ],
     bestiary: [ card + {banishedAt} ],      // cards retired when their monster was banished
     disputes: [ { cardId, misc, option, at, note } ],
     untagged: { "level/circle/option": true } // tags the player disputed; never counted again
   }

   Rules
   - A wrong pick on a tagged option adds a hit to its misconception and puts the circle in the queue,
     due in 1 day. A circle already in the queue goes back to 1 day.
   - Each correct pop-quiz answer moves the card along 1 → 3 → 7 → 21 days. A miss resets it to 1 day.
   - Two correct answers in a row for the same misconception, at least a day apart, banish it: its cards
     leave the queue and go to the bestiary. A later wrong pick on that misconception brings it back.
   - A dispute removes the card, takes its hits off the misconception, and stops that option's tag counting. */
(function (root) {
  const DAY = 86400000;
  const INTERVALS = [1, 3, 7, 21];   // days, by step
  const BANISH_STREAK = 2;

  function empty() {
    return { v: 1, circlesDone: 0, misconceptions: {}, retrievalQueue: [], bestiary: [], disputes: [], untagged: {} };
  }

  function normalize(m) {
    const e = empty();
    if (!m || typeof m !== 'object') return e;
    for (const k of Object.keys(e)) if (!(k in m) || m[k] == null || typeof m[k] !== typeof e[k] || Array.isArray(e[k]) !== Array.isArray(m[k])) m[k] = e[k];
    return m;
  }

  const cardIdOf = (level, circle) => level + '/' + circle;
  const optKey = (level, circle, option) => level + '/' + circle + '/' + option;

  function monster(m, misc) {
    return m.misconceptions[misc] || (m.misconceptions[misc] = { hits: 0, banished: false, streak: 0, lastCorrect: null, banishedAt: null });
  }

  /* A wrong pick on the page or in a pop quiz. Returns the card (or null if the option isn't counted). */
  function recordWrong(m, { level, circle, option, misc }, now) {
    if (!misc || m.untagged[optKey(level, circle, option)]) return null;
    const mc = monster(m, misc);
    mc.hits += 1;
    mc.streak = 0;
    if (mc.banished) { mc.banished = false; mc.banishedAt = null; }
    const id = cardIdOf(level, circle);
    let card = m.retrievalQueue.find(c => c.cardId === id);
    if (card) {
      if (card.misc !== misc) { card.misc = misc; }
      card.option = option; card.step = 0; card.due = now + DAY; card.misses += 1;
    } else {
      m.bestiary = m.bestiary.filter(c => c.cardId !== id);
      card = { cardId: id, level, circle, option, misc, step: 0, due: now + DAY, misses: 1, added: now };
      m.retrievalQueue.push(card);
    }
    return card;
  }

  /* Cards due now, oldest due first. */
  function dueCards(m, now) {
    return m.retrievalQueue.filter(c => c.due <= now && !(m.misconceptions[c.misc] || {}).banished).sort((a, b) => a.due - b.due);
  }

  function nextDue(m) {
    return m.retrievalQueue.reduce((t, c) => Math.min(t, c.due), Infinity);
  }

  /* The first answer to a pop-quiz card. Returns {outcome: 'miss'|'next'|'banished', days?, misc}. */
  function answer(m, cardId, correct, now, wrongOption) {
    const card = m.retrievalQueue.find(c => c.cardId === cardId);
    if (!card) return { outcome: 'gone' };
    const mc = monster(m, card.misc);
    if (!correct) {
      mc.hits += 1; mc.streak = 0;
      card.step = 0; card.due = now + DAY; card.misses += 1;
      if (wrongOption != null) card.option = wrongOption;
      return { outcome: 'miss', days: 1, misc: card.misc };
    }
    if (mc.lastCorrect == null || now - mc.lastCorrect >= DAY) mc.streak += 1;
    mc.lastCorrect = now;
    card.step = Math.min(card.step + 1, INTERVALS.length - 1);
    card.due = now + INTERVALS[card.step] * DAY;
    if (mc.streak >= BANISH_STREAK) {
      mc.banished = true; mc.banishedAt = now;
      const gone = m.retrievalQueue.filter(c => c.misc === card.misc);
      m.retrievalQueue = m.retrievalQueue.filter(c => c.misc !== card.misc);
      for (const c of gone) m.bestiary.push({ ...c, banishedAt: now });
      return { outcome: 'banished', misc: card.misc };
    }
    return { outcome: 'next', days: INTERVALS[card.step], misc: card.misc };
  }

  /* "That wasn't my mistake." */
  function dispute(m, cardId, now, note) {
    const card = m.retrievalQueue.find(c => c.cardId === cardId) || m.bestiary.find(c => c.cardId === cardId);
    if (!card) return false;
    m.disputes.push({ cardId, misc: card.misc, option: card.option, at: now, note: note || '' });
    m.untagged[optKey(card.level, card.circle, card.option)] = true;
    const mc = m.misconceptions[card.misc];
    if (mc) {
      mc.hits = Math.max(0, mc.hits - (card.misses || 1));
      if (mc.hits === 0 && !m.retrievalQueue.some(c => c !== card && c.misc === card.misc) && !m.bestiary.some(c => c !== card && c.misc === card.misc)) delete m.misconceptions[card.misc];
    }
    m.retrievalQueue = m.retrievalQueue.filter(c => c !== card);
    m.bestiary = m.bestiary.filter(c => c !== card);
    return true;
  }

  const api = { DAY, INTERVALS, BANISH_STREAK, empty, normalize, recordWrong, dueCards, nextDue, answer, dispute, cardIdOf, optKey };
  root.MORPlayer = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
