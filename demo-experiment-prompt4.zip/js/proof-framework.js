/* Proof-framework checks for BOSS pages: fill-in-the-blank matching and step-order scoring.
   Pure functions (no DOM); tested by tools/proof_framework_test.js. */
(function (root) {
  const SUP = { '⁰': '0', '¹': '1', '²': '2', '³': '3', 'ⁿ': 'n' };

  /* Make equivalent phrasings look the same before matching. */
  function normalize(s) {
    let t = String(s || '').toLowerCase().normalize('NFC').trim();
    t = t.replace(/[“”"'`]/g, '').replace(/[.;:!?]+$/, '');
    t = t.replace(/\b(greater than or equal to|at least|no less than)\b/g, '>=').replace(/≥|=>/g, '>=');
    t = t.replace(/\b(less than or equal to|at most)\b/g, '<=').replace(/≤|=</g, '<=');
    t = t.replace(/\b(greater than|more than|bigger than|larger than)\b/g, '>').replace(/\bless than\b/g, '<');
    t = t.replace(/\bzero\b/g, '0').replace(/\bone\b(?=\s*$)/g, 'one').replace(/\btwo\b/g, '2');
    t = t.replace(/\bto the (power of |power )?n(th)?\b/g, '^n').replace(/\braised to the (power )?n(th)?( power)?\b/g, '^n');
    t = t.replace(/\b(the )?n-?th power of (\w+)/g, '$2^n');
    t = t.replace(/\*\*/g, '^').replace(/[{}]/g, '');
    t = t.replace(/[⁰¹²³ⁿ]/g, c => '^' + SUP[c]);
    t = t.replace(/\^\((\w)\)/g, '^$1');
    t = t.replace(/\s*([<>=∈^+])\s*/g, '$1').replace(/>=/g, '>=');
    t = t.replace(/^(a|an|the)\s+/, '');
    t = t.replace(/\s+/g, ' ').trim();
    return t;
  }

  /* blank = {answer, accept: [regex], hints: [{match, text}], hint}. Returns {ok, hint}. */
  function checkBlank(blank, input) {
    const t = normalize(input);
    if (!t) return { ok: false, hint: 'Fill in the blank first.' };
    for (const r of blank.accept || []) if (new RegExp(r, 'u').test(t)) return { ok: true, norm: t };
    for (const h of blank.hints || []) if (new RegExp(h.match, 'u').test(t)) return { ok: false, hint: h.text, norm: t };
    return { ok: false, hint: blank.hint || 'Not quite. Check the theorem statement.', norm: t };
  }

  /* An order is valid when every step comes after all the steps in its `after` list. */
  function isValidOrder(steps, order) {
    const pos = Object.fromEntries(order.map((id, i) => [id, i]));
    if (order.length !== steps.length || steps.some(s => !(s.id in pos))) return false;
    return steps.every(s => (s.after || []).every(a => pos[a] < pos[s.id]));
  }

  /* Adjacent-pair credit against the listed order; any valid order gets full credit.
     Returns {valid, credit, total, good: [true/false for each adjacent pair in the player's order]}. */
  function scoreOrder(steps, order) {
    const total = steps.length - 1;
    const valid = isValidOrder(steps, order);
    const next = {}; steps.forEach((s, i) => { if (i < steps.length - 1) next[s.id] = steps[i + 1].id; });
    const good = order.slice(0, -1).map((id, i) => valid || next[id] === order[i + 1]);
    return { valid, credit: valid ? total : good.filter(Boolean).length, total, good };
  }

  const api = { normalize, checkBlank, isValidOrder, scoreOrder };
  root.MORProof = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
