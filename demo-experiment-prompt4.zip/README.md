# The Margins of Rudin — Chapter 1 demo

**Play it:** https://joseph-does-stuff.github.io/Margins-of-Rudin-DEMO/

A phone game for learning Walter Rudin's *Principles of Mathematical Analysis* (“Baby Rudin”).
Nell buys a used copy for eleven dollars. Every “clearly,” “obviously” and “it follows that” in it has been
circled in pencil by a previous owner who signed *R.V., '94*, with *why?* written beside each one.
You answer the circles.

This demo is Chapter 1, *The Real and Complex Number Systems*:

- **The opening.** Nell finds the book at Second Proof Books, then Prof. Sato's first lecture.
- **The book.** All 18 Chapter 1 pages, from √2 to the Cauchy–Schwarz inequality and the Euclidean norm.
  Tap a circled word and pick the real reason. Right answers write R.V.'s note into the margin; wrong ones
  are crossed out and kept in your monster deck.
- **Teaching June.** Ten optional scenes in the dorm where Nell explains each new definition to her
  roommate June, a piano major. If June doesn't get it, Nell doesn't really have it yet.
- **The playback.** When every page is done, June explains sup to Teo, with one slip for you to catch.

About 45–60 minutes. Your progress saves on your phone.

## Put it on your phone

It runs in the phone's browser, and you can add it to your home screen so it opens like an app
(full screen, and it works offline once it has loaded).

**iPhone (Safari):** open the link, tap the **Share** button, then **Add to Home Screen**.

**Android (Chrome):** open the link, tap the **⋮** menu, then **Install app** (or **Add to Home screen**).

Turn the sound on with the **Music** button on the desk. On an iPhone, flip the ring/silent switch to ring
if you hear nothing.

## About

Made by joseph-does-stuff. Every question and answer is original; item numbers follow Rudin's third edition.
The story and its characters are fiction.

Fonts: STIX Two Text, Caveat, Karla and Nothing You Could Do, all under the SIL Open Font License
(see `fonts/LICENSE-*.txt`).
